@include('web.partials.meta')
@include('web.partials.header')
@include('web.partials.menu')
	<!-- Best Sellers -->
	@yield('content')
	<!-- Adverts -->
@include('web.partials.footer')
