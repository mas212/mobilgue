<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Transmisi extends Model
{
    protected $table = 'transmisis';

    protected $fillable = [
    	'nama'
    ];
}
