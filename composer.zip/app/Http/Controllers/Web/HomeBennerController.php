<?php

namespace App\Http\Controllers\Web;

use Redirect;
use App\Models\Benner;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class HomeBennerController extends Controller
{
	
}
