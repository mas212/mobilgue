<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class JarakTempuh extends Model
{
    protected $table = 'jarak_tempuhs';

    protected $fillable = [
    	'jarak_tempuh'
    ];
}
